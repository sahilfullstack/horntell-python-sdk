import urllib
import warnings
import sys

class Charge():
    def create(self):
        return '5'
